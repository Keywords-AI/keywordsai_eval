# Keywords AI Eval
Keywords AI eval is an open-sourced evaluation package for classification


## Get started
Installation
```
pip install keywordsai-eval
```

requirements-to-poetry
```
xargs poetry add < requirements.txt
```